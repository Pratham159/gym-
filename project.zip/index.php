<?php 
session_start();
include('Database.php');
$plans_result = mysqli_query($conn, "SELECT * FROM plans WHERE is_active=1 ORDER BY price ASC");
$plans_data = [];
while($p = mysqli_fetch_assoc($plans_result)) {
    $plans_data[] = $p;
}
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet" />

  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:wght@400;600;700&display=swap"
    rel="stylesheet" />

  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600&display=swap" rel="stylesheet" />

  <style>
    :root {
      --white: #ffffff;
      --orange: #ff7300;
    }

    body {
      background-color: #000000;
      margin: 0;
      overflow-x: hidden;
    }

    /* --- NAVBAR LOGIC --- */
    .navbar {
      padding: 0;
      /* Strict slimness */
      height: 70px;
      background-color: rgba(0, 0, 0, 0.95);
      backdrop-filter: blur(10px);
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1050;
      display: flex;
      align-items: center;
      border-bottom: 1px solid rgba(255, 115, 0, 0.1);
    }

    .logo {
      display: flex;
      align-items: center;
      margin-top: auto;
      gap: 10px;
      font-size: 24px;
      /* Slightly shrunken for better fit */
      font-weight: 800;
      color: var(--orange);
      text-decoration: none;
      font-family: "Bebas Neue", sans-serif;
    }

    .nav-links {
      display: flex;
      gap: 20px;
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .nav-links a {
      text-decoration: none;
      color: white;
      font-weight: 500;
      font-family: "Barlow", sans-serif;
      text-transform: uppercase;
      font-size: 14px;
      transition: 0.3s;
    }

    .nav-links a:hover {
      color: var(--orange);
    }

    /* --- BUTTONS --- */
    .login-link {
      color: white;
      text-decoration: none;
      font-weight: bold;
      font-size: 14px;
      font-family: "Barlow", sans-serif;
    }

    .btn-register {
      background: linear-gradient(to right, #ff0000, #ff7300);
      padding: 9px 19px;
      border-radius: 5px;
      color: white;
      text-decoration: none;
      font-size: 14px;
      font-weight: bold;
      font-family: "Barlow", sans-serif;
    }

    .btn-register,
    .btn {
      border: none;
      background: linear-gradient(45deg, #ff0000, #ff7300);
      background-size: 200% auto;
      transition: 0.5;
    }

    /* --- HERO SECTION --- */
    /* Update HERO to end in pure black */
    .hero {
      height: 100vh;
      position: relative;
      /* Changed to linear-gradient so the bottom is guaranteed #000000 */
      background: linear-gradient(to bottom, #111 0%, #000 70%);
      display: flex;
      align-items: center;
      overflow: hidden;
    }

    /* --- BACKGROUND TEXT LOGIC --- */
    .bg-watermark {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-family: "Bebas Neue", sans-serif;
      font-size: 18vw;
      /* Increased for more "Full Width" impact */
      font-weight: 900;
      -webkit-text-stroke: 2px rgba(255, 115, 0, 0.2);
      /* Thinner stroke is classier */
      text-shadow: 0 0 40px rgba(255, 115, 0, 0.15);
      color: transparent;
      white-space: nowrap;
      pointer-events: none;
      letter-spacing: 1vw;
      opacity: 0.2;
      user-select: none;
      filter: blur(1px);
    }

    .hero-text {
      text-align: left;
      text-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
      transform: none;
    }

    .main-heading {
      font-size: clamp(32px, 8vw, 60px);
      font-family: "Bebas Neue", sans-serif;
      letter-spacing: 5px;
      color: var(--white);
      transition: transform 0.3s ease;
      display: inline-block;
    }

    .main-heading span {
      color: var(--orange);
      text-shadow: 0 0 20px rgba(255, 115, 0, 0.5);
    }

    .main-heading:hover {
      transform: scale(1.05);
    }

    .hero-text span {
      font-size: clamp(32px, 8vw, 60px);
      font-weight: 800;
      margin-bottom: 10px;
      background-clip: text;
      /* Standard property */
      color: var(--orange);
      transition: transform 0.3s ease;
      display: inline-block;
      /* Required for transform/scale to work properly */
      background: none;
      -webkit-text-fill-color: #ff7300;
      --font-display: "Bebas Neue", sans-serif;
      /* for headings */
      font-family: var(--font-display);
      /* just the heading */
      text-shadow: 0 0 20px rgba(158, 132, 132, 0.6);
    }

    .plans .para {
      font-size: clamp(20px, 2vw, 10px);
      letter-spacing: 2px;
      font-family: "Bebas Neue", sans-serif;
      text-transform: uppercase;
    }

    .hero-text p {
      font-size: clamp(12px, 2vw, 18px);
      letter-spacing: 2px;
      text-transform: uppercase;
      color: #c1c1c1;
      font-family: "Barlow", sans-serif;
      margin: 15px 0 30px 0;
    }

    .hero-text h1:hover {
      transform: scale(1.05);
    }

    .hero-text span:hover {
      transform: scale(1.05);
    }

    .btn {
      background: linear-gradient(to right, #ff0000, #ff7300);
      border: none;
      padding: 10px 35px;
      font-weight: bolder;
      color: white;
      border-radius: 50px;
      /* Gives a cleaner finish */
      transition: 0.5s;
      box-shadow: 0 0 20px rgba(255, 115, 0, 0.4);
    }

    .btn:hover {
      transform: scale(1.05) translateY(-2px);
      box-shadow: 0 0 30px rgba(255, 115, 0, 0.7);
    }

    /* --- MOBILE OVERRIDES --- */
    @media (max-width: 991px) {
      .navbar-collapse {
        background: #111;
        position: absolute;
        top: 70px;
        left: 0;
        width: 100%;
        padding: 20px;
        text-align: center;
        border-bottom: 2px solid var(--orange);
      }

      .nav-links {
        flex-direction: column;
        gap: 15px;
      }

      .navbar-toggler {
        border: none;
      }

      .navbar-toggler:focus {
        box-shadow: none;
      }

      .navbar-toggler-icon {
        filter: invert(1);
      }
    }

    /* --- For Watermark --- */
    @media (max-width: 768px) {
      .bg-watermark {
        font-size: 25vw;
        opacity: 0.1;
      }
    }

    .section-title {
      font-family: "Bebas Neue";
      color: var(--orange);
      letter-spacing: 3px;
    }

    .section {
      padding: 120px 0;
    }

    .about {
      background-color: #000;
      color: white;
      padding-top: 60px;
      /* Adjust this for the spacing you want */
      padding-bottom: 80px;
      margin-top: 0;
      min-height: 80vh;
      background: linear-gradient(to bottom, #000, #0a0a0a);
    }

    .about-text {
      position: relative;
      color: white;
      text-align: center;
      z-index: 2;
      text-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
      margin: auto;
      max-width: 700px;
    }

    .about-text h1:hover {
      transform: scale(1.05);
    }

    .about-text span:hover {
      transform: scale(1.05);
    }

    .about-text p {
      font-size: clamp(12px, 2vw, 18px);
      letter-spacing: 2px;
      text-transform: uppercase;
      color: #c1c1c1;
      font-family: "Barlow", sans-serif;
      margin: 15px 0 30px 0;
    }

    .plans .p {
      font-size: clamp(12px, 2vw, 18px);
      letter-spacing: 2px;
      text-transform: uppercase;
      color: #c1c1c1;
      font-family: "Barlow", sans-serif;
      margin: 15px 0 30px 0;
    }

    .section p {
      font-size: clamp(12px, 2vw, 18px);
      letter-spacing: 2px;
      text-transform: uppercase;
      color: #c1c1c1;
      font-family: "Barlow", sans-serif;
      margin: 15px 0 30px 0;
    }

    .services {
      background-color: #0a0a0a;
    }

    .plans {
      background-color: #000;
      padding: 100px 0;
      position: relative;
      background:
        linear-gradient(to bottom, #0a0a0a, transparent 25%),
        linear-gradient(to top, #0a0a0a, transparent 25%), #000;
    }

    .plans .card {
      background: linear-gradient(145deg, #111, #1a1a1a);
      border: 1px solid rgba(255, 115, 0, 0.08);
      color: white;
      padding: 40px 32px;
      border-radius: 20px;

      box-shadow: 0 0 10px rgba(255, 115, 0, 0.1);
      transition: 0.3s;
    }

    .plans .card h5 {
      font-weight: 600;
      letter-spacing: 2px;
      font-family: "Oswald", sans-serif;
    }

    .plans .card:hover {
      transform: translateY(-5px);
    }

    .lead {
      margin-bottom: 3rem;
      letter-spacing: 4px;
      font-size: 0.9rem;
      color: #888;
    }

    .why-card {
      background: linear-gradient(145deg, #0a0a0a, #111);
      padding: 25px;
      border-radius: 13px;
      transition: 0.3s;
      height: 100%;
      border: 1px solid rgba(255, 115, 0, 0.08);
    }

    .why-card:hover {
      transform: translateY(-5px) scale(1.02);
      box-shadow: 0 0 20px rgba(255, 115, 0, 0.4);
    }

    .icon {
      font-size: 30px;
      color: var(--orange);
      margin-bottom: 15px;
      display: inline-flex;
      width: 60px;
      height: 60px;
      margin-bottom: 15px;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      box-shadow: 0 0 15px rgba(255, 115, 0, 0.3);
    }

    .why-card h5 {
      margin-top: 10px;
      font-weight: 600;
    }

    .why-card p {
      font-size: 14px;
      color: #aaa;
    }

    .plans h2 {
      color: var(--orange);
      font-family: "Bebas Neue";
    }

    .plans li {
      font-size: clamp(12px, 2vw, 18px);
      letter-spacing: 1px;
      text-transform: capitalize;
      color: #c1c1c1;
      font-family: "Barlow", sans-serif;
      margin-bottom: 5px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.07);
      padding: 10px 0;
    }

    .plans li:last-child {
      border-bottom: none;
    }

    .plan-divider {
      border: none;
      border-top: 1px solid rgba(255, 255, 255, 0.07);
      margin: 14px 0;
    }

    .btn-butt {
      background: transparent;
      border: none;
      padding: 10px 35px;
      font-weight: bolder;
      color: white;
      border-radius: 50px;
      /* Gives a cleaner finish */

      box-shadow: 0 0 1px rgba(228, 227, 227, 0.4);
    }

    .btn-butt:hover {
      transform: scale(1.02) translateY(-3px);
      box-shadow: 0 0 5px rgba(104, 104, 104, 0.7);
    }

    .plans .card h2 {
      color: var(--orange);
    }

    .plans .card:last-child {
      border: 1px solid rgba(255, 115, 0, 0.3);

      background: linear-gradient(145deg, #1a1a1a, #111);
    }

    .plans .card:last-child h2 {
      color: #ff9a3c;
    }

    .plans li i {
      color: var(--orange);
    }

    .not-included {
      opacity: 0.4;
      text-decoration: line-through;
    }

    .not-included i {
      color: #666;
    }

    .duration {
      font-size: 14px;
      font-weight: 500;
      color: #aaa;
      letter-spacing: 1px;
      border: rgba(255, 115, 0, 0.2);
      display: inline-block;
      border-radius: 20px;
      margin-bottom: 12px;
      margin-left: 0;
    }

    .plans .card.popular {
      transform: scale(1.05);
      border: 1px solid var(--orange);
      box-shadow: 0 0 25px rgba(255, 115, 0, 0.4);
      position: relative;
      z-index: 2;
      background: linear-gradient(145deg, #222, #1a1a1a);
      transform: scale(1.05);
    }

    .popular .btn-butt {
      background: linear-gradient(to right, #ff0000, #ff7300);
      color: white;
      box-shadow: 0 0 15px rgba(255, 115, 0, 0.09);
    }

    .contact .btn-butt {
      background: linear-gradient(to right, #ff0000, #ff7300);
      color: white;
      box-shadow: 0 0 15px rgba(255, 115, 0, 0.09);
    }

    .plans .card:last-child .btn-butt {
      border: 1px solid rgba(255, 115, 0, 0.5);
    }

    .badge-popular {
      position: absolute;
      top: -12px;
      right: 15px;
      background: linear-gradient(to right, #ff0000, #ff7300);
      color: white;
      font-size: 11px;
      font-weight: 600;
      padding: 6px 14px;
      border-radius: 20px;
      letter-spacing: 1.5px;
    }

    .badge-popular-trainer {
      position: relative;
      background: linear-gradient(to right, #ff0000, #ff7300);
      color: white;
      font-size: 11px;
      font-weight: 600;
      padding: 6px 12px;
      border-radius: 10px;
      letter-spacing: 1.5px;
    }

    @media (min-width: 768px) {
      .popular {
        margin-top: -10px;
      }
    }

    .info {
      font-size: 13px;
      letter-spacing: 2px;
      text-transform: capitalize;
      color: #c1c1c1;
      font-family: sans-serif;
      margin-top: -5px;
      margin-bottom: 10px;
      opacity: 0.5;
    }

    .plans .memb {
      -webkit-text-fill-color: #ff7300;
      font-family:
        Bebas Neue,
        sans-sarif;
      font-weight: 800;
      font-size: 20px;
      letter-spacing: 5px;
    }

    .trainer-card-pro {
      background: #111;
      border-radius: 20px;
      overflow: hidden;
      border: 1px solid rgba(255, 115, 0, 0.1);
      transition: 0.4s;
    }

    .contact {
      background: #111;
      border-radius: 20px;
      overflow: hidden;
      border: 1px solid rgba(255, 115, 0, 0.1);
      transition: 0.4s;
    }

    .trainer-card-pro:hover {
      border-color: var(--orange);
      transform: translateY(-10px);
    }

    .trainer-img-container {
      height: 350px;
      /* Adjust based on your photo */
      position: relative;
      overflow: hidden;
    }

    .trainer-img-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
    }

    .trainer-details {
      padding: 25px;
      background: linear-gradient(to bottom, #111, #000);
    }

    .trainer-details h3 {
      font-family: "Bebas Neue", sans-serif;
      letter-spacing: 2px;
      color: #fff;
      margin-bottom: 5px;
    }

    .trainer-details .specialty {
      color: var(--orange);
      font-family: "Barlow", sans-serif;
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 1px;
      display: block;
      margin-bottom: 15px;
    }

    .trainer-details .bio {
      color: #aaa;
      font-size: 14px;
      line-height: 1.6;
      margin-bottom: 20px;
    }

    .contact-item {
      display: flex;
      align-items: start;
      gap: 15px;
      margin-bottom: 20px;
    }

    .contact-item i {
      font-size: 20px;
      min-width: 40px;
      color: #ff7300;
      margin-top: 2px;
      height: 40px;
      width: 45px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 115, 0, 0.08);
      border-radius: 10px;
    }

    .contact-item h6 {
      margin: 0;
      font-size: 12px;
      letter-spacing: 2px;
      color: #888;
      font-family: "Barlow", sans-serif;
      align-items: start;
      justify-content: start;
    }

    .contact-item p {
      margin: 4px 0 0;
      font-size: 12px;
      line-height: 1.6;
      color: #ddd;
    }

    .form-control {
      background: #0a0a0a;
      border: 1px solid rgba(255, 115, 0, 0.1);
      color: white;
      padding: 12px;
    }

    .form-control:focus {
      background: #0a0a0a;
      border-color: #ff7300;
      box-shadow: none;
      color: white;
    }

    textarea.form-control {
      resize: none;
    }

    .footer {
      background: #000;
      padding: 50px 0 20px;
      border-top: 1px solid rgba(255, 115, 0, 0.1);
    }

    .footer-logo {
      font-family: "Bebas Neue", sans-serif;
      letter-spacing: 3px;
      color: var(--orange);
      margin-bottom: 5px;
    }

    .footer-text {
      font-size: 13px;
      color: #aaa;
      letter-spacing: 2px;
    }

    .footer-social a {
      color: #aaa;
      font-size: 25px;
      margin-left: 10px;
      transition: 0.09s;
    }

    .footer-social a:hover {
      color: var(--orange);
    }

    .footer-divider {
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      margin: 25px 0 15px;
    }

    .copyright {
      font-size: 12px;
      color: #777;
      letter-spacing: 1px;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid px-lg-5">
      <a class="logo" href="#">
        <img class="img" style="
              height: 40px;
              width: 40px;
              border-radius: 50%;
              object-fit: cover;
            " src="https://res.cloudinary.com/de029k6ik/image/upload/f_auto,q_auto/Untitled_jwwaxh" alt="Logo" />
        U.S. Fitness
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="nav-links mx-auto">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#plans">Plans</a></li>
          <li><a href="#trainers">Trainers</a></li>
          <li><a href="#contact">Contact</a></li>
          <li><a href="login.php">Admin</a></li>
        </ul>
      </div>
      <div class="d-flex align-items-center justify-content-center gap-3 ">
        <a href='user_login.php' class="login-link">Login</a>
        <a href='user_register.php' class="btn-register">Register</a>
      </div>
    </div>

  </nav>

  <section id="home" class="hero section">
    <div class="container">
      <div class="bg-watermark">STRENGTH</div>
      <div class="hero-text">
        <span>U.S.</span>
        <h1 class="main-heading">FITNESS</h1>
        <p><strong>Strength • Discipline • Results</strong><br />EST 2025</p>
        <a href="user_register.php" class="btn btn-hover">JOIN NOW</a>
      </div>
    </div>
  </section>

  <section id="about" class="about section">
    <div class="container">
      <div class="about-text col-lg-6 mx-auto">
        <h1 class="main-heading">
          Why Choose
          <span>U.S.</span>
        </h1>
        <p class="lead">No shortcuts. No excuses. Just results.</p>
      </div>
      <div class="row g-4">
        <div class="col-md-6 col-lg-3">
          <div class="why-card text-center">
            <i class="bi bi-person-check icon"></i>
            <h5>Certified Trainers</h5>
            <p>Expert guidance for safe and effective workouts</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-3">
          <div class="why-card text-center">
            <i class="bi bi-gear icon"></i>
            <h5>Modern Equipment</h5>
            <p>Train with high-quality machines and tools</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-3">
          <div class="why-card text-center">
            <i class="bi bi-graph-up icon"></i>
            <h5>Proven Results</h5>
            <p>Programs focused on real transformation</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-3">
          <div class="why-card text-center">
            <i class="bi bi-fire icon"></i>
            <h5>Motivating Environment</h5>
            <p>Push your limits every day</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="plans" class="plans text-center text-white">
    <div class="container">
      <p class="info memb">Membership Plans</p>
      <h1 class="main-heading text-center">Choose Your<span> Level</span></h1>
      <p class="lead p">Choose your plan and start your journey</p>

      <div class="row g-4 mt-4">
        <?php foreach($plans_data as $i => $plan): ?>
        <div class="col-md-4">
          <div class="card text-start <?php echo $i === 1 ? 'popular' : ''; ?>">
            <?php if($i === 1): ?><div class="badge-popular">MOST POPULAR</div><?php endif; ?>
            <h5 class="mb-4"><?php echo htmlspecialchars($plan['name']); ?> Plan</h5>
            <p class="info"><?php echo htmlspecialchars($plan['features'] ?? ''); ?></p>
            <h2 class="mb-2">₹<?php echo number_format($plan['price'], 0); ?></h2>
            <p class="para mb-2" style="opacity: 0.4">/plan</p>
            <p class="duration"><?php echo $plan['duration_days']; ?> Days Access</p>
            <ul class="list-unstyled" style="margin-top: 10px">
              <li><i class="bi bi-check-circle me-2"></i>Gym Access</li>
              <li><i class="bi bi-check-circle me-2"></i>Basic Equipment</li>
              <li><i class="bi bi-check-circle me-2"></i>Changing Room</li>
              <li class="<?php echo $plan['duration_days'] >= 90 ? '' : 'not-included'; ?>">
                <i class="bi bi-<?php echo $plan['duration_days'] >= 90 ? 'check' : 'x'; ?>-circle me-2"></i>Personal Trainer
              </li>
              <li class="<?php echo $plan['duration_days'] >= 180 ? '' : 'not-included'; ?>">
                <i class="bi bi-<?php echo $plan['duration_days'] >= 180 ? 'check' : 'x'; ?>-circle me-2"></i>Diet Plan
              </li>
            </ul>
            <a href="user_login.php" class="btn btn-butt mt-3 w-100">Get Started</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- Trainers Section -->
  <section id="trainers" class="section trainer plans text-center text-white">
    <div class="container">
      <p class="info memb">Our Trainers</p>
      <h1 class="main-heading text-center">Meet Our<span> Experts</span></h1>
       <p class="lead p">Train with our best professionals</p>

      <div class="row g-4 mt-4">
        <?php
          include('Database.php');
        $sql = "SELECT * FROM trainers";
        $result = mysqli_query($conn, $sql);

        while ($row = mysqli_fetch_array($result)) {
          echo '
        <div class="col-md-3">
            <div class="trainer-card-pro">
                <div class="trainer-img-container">
                    <img src="' . $row['photo'] . '" class="img-fluid" />
                </div>
                <div class="trainer-details text-start">
                    <h3 class="mb-1 text-uppercase">' . $row['name'] . '</h3>
                    <span class="specialty">' . $row['specialization'] . '</span>
                    <p class="bio">' . $row['bio'] . '</p>
                </div>
            </div>
        </div>';
        }
        ?>
      </div>
  </section>

  <!-- Contact -->
  <section id="contact" class="section text-white">
    <div class="container text-center">
      <p class="info memb"></p>
      <h1 class="main-heading text-center">Get In<span> Touch</span></h1>
      <p class="lead p">Ready to transform? Visit us or drop a message.</p>
    </div>
    <div class="container">
      <div class="row g-4 mt-4 justify-content-center">
        <div class="col-md-6 col-lg-5">
          <div class="contact p-4 h-100">
            <h4 class="mb-4">Contact Info.</h4>
            <div class="contact-item">
              <i class="bi bi-geo-alt"></i>
              <div>
                <h6>ADDRESS</h6>
                <p>
                  123 Fitness Lane, Near Kunthunath Derasar,<br />
                  Surendranagar, Gujarat
                </p>
              </div>
            </div>

            <div class="contact-item">
              <i class="bi bi-telephone"></i>
              <div>
                <h6>PHONE</h6>
                <p>+91 98765 43210</p>
              </div>
            </div>

            <div class="contact-item">
              <i class="bi bi-envelope"></i>
              <div>
                <h6>EMAIL</h6>
                <p>usfitness@gmail.com</p>
              </div>
            </div>

            <div class="contact-item">
              <i class="bi bi-clock"></i>
              <div>
                <h6>TIMING</h6>
                <p>Mon - Sat: 6AM - 10PM</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-7">
          <div class="contact p-4 h-100">
            <form action="contact.php" method="POST">
              <div class="row g-5">
                <div class="col-md-6">
                  <input name="name" type="text" class="form-control" placeholder="Your Full Name" required />
                </div>

                <div class="col-md-6">
                  <input name="email" type="email" class="form-control" placeholder="Email Address" required />
                </div>

                <div class="col-12">
                  <input name="phone" type="tel" class="form-control" placeholder="Phone Number" required />
                </div>

                <div class="col-12">
                  <textarea name="message" type="text" class="form-control" placeholder="Your message or inquiry..."
                    required></textarea>
                </div>

                <div class="col-12">
                  <button type="submit" name="send" class="btn btn-butt w-100">
                    Send Message
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer class="footer">
    <div class="container">
      <div class="row align-items-center">
        <!--Left Side-->
        <div class="col-md-6 text-md-start text-center mb-3 mb-md-0">
          <h5 class="footer-logo">U.S. FITNESS</h5>
          <p class="footer-text">Strength • Discipline • Results</p>
        </div>

        <!--Right Side-->
        <div class="col-md-6 text-md-end text-center">
          <div class="footer-social">
            <a href="#"><i class="bi bi-instagram"></i></a>
            <a href="#"><i class="bi bi-facebook"></i></a>
            <a href="#"><i class="bi bi-whatsapp"></i></a>
          </div>
        </div>
      </div>

      <hr class="footer-divider" />

      <p class="copyright text-center mb-0">
        © 2026 U.S. Fitness. All Rights Reserved.
      </p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>