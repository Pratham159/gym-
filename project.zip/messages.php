<?php
session_start();
if (!isset($_SESSION['name'])) { header("Location: login.php"); exit(); }
include('Database.php');

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM contact_messages WHERE id=$id");
    header("Location: messages.php");
    exit();
}

$res = mysqli_query($conn, "SELECT * FROM contact_messages ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages — Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0a; --surface: #111111; --card: #161616;
            --border: #222222; --accent: #ff4500; --accent2: #ff7300;
            --text: #f0f0f0; --muted: #666;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }

        /* SIDEBAR */
        .sidebar { width: 240px; background: var(--surface); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; height: 100vh; }
        .logo { padding: 28px 24px; border-bottom: 1px solid var(--border); }
        .logo h1 { font-family: 'Bebas Neue', sans-serif; font-size: 26px; letter-spacing: 2px; background: linear-gradient(135deg, var(--accent), var(--accent2)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .logo p { font-size: 11px; color: var(--muted); letter-spacing: 1px; text-transform: uppercase; margin-top: 2px; }
        .nav { padding: 20px 12px; flex: 1; }
        .nav-label { font-size: 10px; text-transform: uppercase; letter-spacing: 2px; color: var(--muted); padding: 0 12px; margin: 16px 0 8px; }
        .nav a { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; color: var(--muted); text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.2s; margin-bottom: 2px; }
        .nav a:hover, .nav a.active { background: rgba(255,69,0,0.1); color: var(--accent2); }
        .nav a .icon { font-size: 16px; width: 20px; text-align: center; }
        .sidebar-footer { padding: 16px 12px; border-top: 1px solid var(--border); }
        .admin-info { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: var(--card); border-radius: 8px; margin-bottom: 8px; }
        .avatar { width: 32px; height: 32px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 13px; flex-shrink: 0; }
        .admin-info .name { font-size: 13px; font-weight: 600; }
        .admin-info .role { font-size: 11px; color: var(--muted); }
        .logout-btn { display: block; text-align: center; padding: 8px; background: rgba(255,69,0,0.1); color: var(--accent); border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 600; transition: all 0.2s; }
        .logout-btn:hover { background: var(--accent); color: white; }

        /* MAIN */
        .main { margin-left: 240px; flex: 1; padding: 32px; }
        .page-header { margin-bottom: 32px; }
        .page-header h2 { font-family: 'Bebas Neue', sans-serif; font-size: 36px; letter-spacing: 2px; }
        .page-header p { color: var(--muted); font-size: 14px; margin-top: 4px; }

        .section { background: var(--card); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; }
        .section-header { padding: 18px 24px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
        .section-header h3 { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 1px; }
        .badge { background: rgba(255,69,0,0.15); color: var(--accent2); font-size: 12px; padding: 3px 10px; border-radius: 20px; font-weight: 600; }

        table { width: 100%; border-collapse: collapse; }
        th { padding: 12px 24px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: var(--muted); background: rgba(255,255,255,0.02); border-bottom: 1px solid var(--border); }
        td { padding: 14px 24px; font-size: 14px; border-bottom: 1px solid rgba(255,255,255,0.04); vertical-align: top; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: rgba(255,255,255,0.02); }
        .msg-text { color: var(--muted); font-size: 13px; max-width: 300px; line-height: 1.5; }
        .delete-btn { background: rgba(239,68,68,0.1); color: #ef4444; border: none; padding: 5px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600; text-decoration: none; transition: all 0.2s; }
        .delete-btn:hover { background: #ef4444; color: white; }
        .no-data { padding: 40px; text-align: center; color: var(--muted); font-size: 14px; }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="logo"><h1>U.S. FITNESS</h1><p>Admin Panel</p></div>
    <nav class="nav">
        <div class="nav-label">Overview</div>
        <a href="admin_dashboard.php"><span class="icon">⚡</span> Dashboard</a>
        <div class="nav-label">Manage</div>
        <a href="admin_members.php"><span class="icon">👥</span> Members</a>
        <a href="admin_subscriptions.php"><span class="icon">📋</span> Subscriptions</a>
        <a href="admin_plans.php"><span class="icon">💪</span> Plans</a>
        <a href="admin_trainers.php"><span class="icon">🏋️</span> Trainers</a>
        <a href="messages.php" class="active"><span class="icon">✉️</span> Messages</a>
    </nav>
    <div class="sidebar-footer">
        <div class="admin-info">
            <div class="avatar"><?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?></div>
            <div><div class="name"><?php echo $_SESSION['name']; ?></div><div class="role">Administrator</div></div>
        </div>
        <a href="user_logout.php" class="logout-btn">Logout</a>
    </div>
</aside>

<main class="main">
    <div class="page-header">
        <h2>Messages</h2>
        <p>Contact form submissions from visitors</p>
    </div>
    <div class="section">
        <div class="section-header">
            <h3>All Messages</h3>
            <span class="badge"><?php echo mysqli_num_rows($res); ?> Total</span>
        </div>
        <?php if (mysqli_num_rows($res) > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Message</th>
                <th>Action</th>
            </tr>
            <?php while($row = mysqli_fetch_array($res)): ?>
            <tr>
                <td>#<?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['phone'] ?? '-'); ?></td>
                <td><div class="msg-text"><?php echo htmlspecialchars($row['message']); ?></div></td>
                <td><a href="?delete=<?php echo $row['id']; ?>" class="delete-btn" onclick="return confirm('Delete this message?')">Delete</a></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <?php else: ?>
        <div class="no-data">No messages yet</div>
        <?php endif; ?>
    </div>
</main>

</body>
</html>
